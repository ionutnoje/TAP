#include "DreptunghicIsoscel.h"
