#include "Isoscel.h"
