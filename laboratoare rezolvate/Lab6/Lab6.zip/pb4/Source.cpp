#include "Laptop.h"
int main() {
	Dispozitiv dispoizitiv;
	Monitor monitor;
	Tastatura tastatura;
	Laptop laptop;
	dispoizitiv.afisareSpecificatii();
	monitor.afisareSpecificatii();
	tastatura.afisareSpecificatii();
	laptop.afisareSpecificatii();
}